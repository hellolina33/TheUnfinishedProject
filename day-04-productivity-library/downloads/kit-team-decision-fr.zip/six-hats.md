# Les six chapeaux de la réflexion

Sépare faits, émotions, risques, bénéfices, idées et conduite de la discussion.

1. Parcours les six angles
2. Note les contradictions
3. Choisis une suite concrète

Une équipe débat d’un nouveau circuit fournisseur. Les faits, les craintes de surcharge et les idées de pilote se mélangent.

Douze demandes, c’est un fait. La crainte de surcharge est une réaction. Le délai fournisseur est un risque. Un pilote limité est une idée à tester à partir de ces éléments.

Écris une décision de pilote avec un risque à surveiller et un bénéfice à mesurer.

Edward de Bono, Six Thinking Hats (1985).
