# Cadre Cynefin

Adapte la manière d’agir à la nature de la situation.

1. Décris ce que tu sais
2. Estime si les causes sont prévisibles
3. Choisis procédure, expertise, essai ou stabilisation

Un centre d’assistance gère une réinitialisation documentée, une panne difficile à diagnostiquer, un nouveau service et un incident actif.

Une réinitialisation documentée suit la procédure. Une panne inhabituelle demande une expertise. Un nouveau service mérite un petit essai. Un incident actif doit d’abord être contenu.

Vérifie que la réponse à chaque problème tient compte de son degré d’incertitude.

Dave Snowden et Mary Boone, Harvard Business Review (2007).
