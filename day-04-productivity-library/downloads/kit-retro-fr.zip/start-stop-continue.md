# Commencer, arrêter, continuer

Transforme un bilan en trois décisions simples sur les pratiques.

1. Note un exemple dans chaque colonne
2. Choisis le changement le plus utile
3. Fixe une date de revue

Deux personnes rédigent le même compte rendu. Le suivi écrit est utile, mais la réunion démarre souvent sans ordre du jour.

Le suivi écrit est utile, donc garde-le. Deux comptes rendus font doublon, donc supprime-en un. Essaie d’envoyer un ordre du jour avant la prochaine réunion.

Vérifie à la prochaine réunion si un ordre du jour et un compte rendu ont suffi.

Pratique courante des rétrospectives agiles. Auteur unique non établi.
