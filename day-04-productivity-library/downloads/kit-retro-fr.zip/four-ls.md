# Rétrospective des quatre L

Collecte quatre types de retours pour identifier un ajustement concret.

1. Écris un fait par rubrique
2. Cherche les répétitions
3. Choisis une action testable

Une équipe de test apprend un raccourci grâce à l’entraide, mais le groupe suivant manque d’instructions écrites.

L’équipe a apprécié l’entraide et appris un raccourci. Elle a manqué de documentation et souhaité plus de temps de test. Documenter le raccourci permet au groupe suivant de l’essayer seul.

Demande à une personne extérieure au groupe initial d’utiliser le raccourci documenté.

Mary Gorman et Ellen Gottesdiener, The 4L’s: A Retrospective Technique, EBG Consulting (2010).
