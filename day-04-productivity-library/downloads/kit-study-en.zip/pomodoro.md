# Pomodoro

Turns a big block into short sprints with a visible end, which makes starting easier.

1. Pick one task. Set a timer for 25 minutes.
2. Work only on that task until the timer rings.
3. Take a five-minute break. After four rounds, take a longer one.

An author has two hours for a draft and keeps switching to messages whenever the next paragraph gets difficult.

Outline in the first block and draft one section in each later block. A short break separates blocks. Save the longer break for after the fourth.

Count the completed draft sections after four work blocks and record where interruptions occurred.

Francesco Cirillo, late 1980s.
