# Weekly Review

A fixed weekly session that keeps the other systems honest. Without it, lists go stale.

1. Pick the same slot each week. Friday afternoon works for many people.
2. Clear inboxes and capture loose items.
3. Read last week's list: what got done, what did not, and why.
4. Choose three priorities for next week and block them in the calendar.

Six notes and two files remain open on Friday, while a key appointment is still unconfirmed.

Process the six notes, confirm the appointment and schedule the two follow-ups. Then reserve Tuesday for the most important work left.

Start Monday with no unexplained note and a protected block for the next priority.

David Allen, Getting Things Done (2001).
