# Time Blocking

Gives each type of work a fixed slot in the calendar, so tasks compete for time, not for your attention.

1. Block the week: deep work, admin, meetings, breaks.
2. Put each task into the block that matches it.
3. When a block ends, stop, even if the task is not finished.

A writer has missed two drafting sessions because calls and invoices filled the morning.

Reserve writing at 9 am. Put invoices and supplier calls into separate slots so they do not silently consume that block.

Track whether the 9 am block actually happens three days in a row.

No single inventor. Widely described in productivity writing, for example Cal Newport, Deep Work (2016).
