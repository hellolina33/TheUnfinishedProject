# DACI

Clarify who drives a decision, who approves it and who contributes or is informed.

1. Write the decision in one sentence.
2. Name one Driver and one Approver.
3. Add Contributors and Informed, then publish the decision date.

A supplier decision has several contributors and no clear person responsible for making the final call.

Sam gathers vendor inputs from Noor and prepares the options. Lea makes the call by the deadline, and the team receives the decision and its rationale.

Confirm that Lea decides by the deadline and that the team receives the rationale.

DACI decision framework associated with Intuit.
