# Rituel de fin de journée

Capture ce qui reste ouvert avant de quitter le travail.

1. Parcours les messages
2. Consigne les prochaines actions
3. Ferme les outils après avoir préparé demain

Un devis fournisseur et deux courriels restent en tête après la fermeture de l’ordinateur.

La relance du devis devient une tâche datée et l’appel de 9 h devient la première action du lendemain. Tu peux fermer l’ordinateur une fois les engagements rangés.

Commence à 9 h par l’appel prévu et vérifie si un engagement ouvert manquait de prochaine action.

Cal Newport, Deep Work (2016).
