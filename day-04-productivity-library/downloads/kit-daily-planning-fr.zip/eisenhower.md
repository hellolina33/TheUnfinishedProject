# Matrice d’Eisenhower

Classe les tâches selon leur urgence et leur importance.

1. Liste tes tâches
2. Évalue leur urgence et leur importance
3. Traite les urgences importantes et réserve un créneau pour le reste

Une boutique doit gérer une panne de paiement, une échéance budgétaire et des rapports en attente.

La panne bloque les ventes en cours, donc elle passe en premier. Le budget garde son créneau jeudi. Supprimer le rapport en double ne fait perdre aucune information.

Vérifie que le paiement fonctionne et que le créneau du budget est toujours réservé jeudi.

Discours de Dwight D. Eisenhower (1954), puis popularisation par Stephen Covey (1989).
