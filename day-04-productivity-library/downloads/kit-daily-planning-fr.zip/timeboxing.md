# Limites de temps

Fixe une durée maximale et une définition de résultat avant de commencer.

1. Définis le résultat minimum
2. Fixe une limite et lance le minuteur
3. Arrête-toi pour décider de la suite

Une échéance d’une heure laisse juste assez de temps pour un plan, une relecture et un envoi exploitable.

Passe 30 min à rédiger, 15 à relire et 15 à envoyer. À la trentième minute, passe à la relecture si l’essentiel est présent. Note à part ce qui reste à reprendre.

À la trentième minute, arrête la rédaction et vérifie que les points essentiels sont présents.

James Martin, Rapid Application Development (1991). Pratique employée dans la méthode DSDM.
