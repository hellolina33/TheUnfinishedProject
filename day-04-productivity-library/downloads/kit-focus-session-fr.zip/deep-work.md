# Travail en profondeur

Protège du temps sans interruption pour une tâche exigeante.

1. Définis une production attendue
2. Coupe les interruptions pendant le bloc
3. Note ce que tu as terminé

Une analyste doit valider un modèle et interpréter ses résultats avant de répondre aux demandes courantes.

Le premier bloc sert au test reproductible du modèle et le second à l’interprétation écrite. Les demandes courantes attendent ces résultats.

Vérifie si les deux blocs ont produit un test reproductible et une interprétation écrite.

Cal Newport, Deep Work (2016).
