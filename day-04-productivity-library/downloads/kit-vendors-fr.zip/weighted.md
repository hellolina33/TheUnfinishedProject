# Matrice de décision pondérée

Compare plusieurs options selon des critères dont l’importance est explicite.

1. Définis les critères et leurs poids
2. Note chaque option sur la même échelle
3. Multiplie les notes par les poids et teste la sensibilité

Trois fournisseurs se distinguent par le coût, les délais et la maintenance. L’équipe veut fixer les poids avant de voir les totaux.

L’option C obtient 0,40 × 4 + 0,35 × 3 + 0,25 × 5 = 3,90. A et B obtiennent chacune 3,70. Cette faible avance justifie de tester le poids du délai.

Modifie le poids des délais et vérifie si le fournisseur C reste premier.

La matrice de Stuart Pugh, en conception industrielle, est apparentée à la notation pondérée.
