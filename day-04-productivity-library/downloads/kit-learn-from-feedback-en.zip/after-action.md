# After Action Review

Four questions asked straight after an event, to learn from what went differently from the plan.

1. Write what you planned to happen, and what happened.
2. Explain each difference in one sentence.
3. Choose one thing to sustain and one thing to improve.

A noon delivery arrives at 2 pm. The team needs to understand the gap before repeating the same plan.

The team aimed for noon and delivered at 2 pm. Data arrived late. Requesting it the day before gives the team a change it can test on the next run.

Request data the day before and record the actual delivery time on the next run.

US Army, After Action Review (formalised in the 1970s).
