# Start, Stop, Continue

Turns feedback into three kinds of action: what to begin, what to end, and what to keep.

1. Write three lists for the last week: start, stop, continue.
2. Pick one item from Start and one from Stop.
3. Test them next week, and note the result.

Two people write the same meeting minutes. The written follow-up is useful, but the meeting often starts without an agenda.

The written follow-up is useful, so keep it. Two sets of minutes are redundant, so stop one. Try sending an agenda before the next meeting.

Check at the next meeting whether one agenda and one record were enough.

No verified single author. Common in agile team retrospectives.
