# 4Ls Retrospective

Adds 'lacked' and 'longed for' to a retrospective, so people name what was missing, not only what went wrong.

1. Write one line per column about your last project or week.
2. Choose one 'lacked' item and one 'longed for' item to act on.
3. Put both actions in your calendar for next week.

A test team learns a shortcut through mutual help but lacks written instructions for the next group.

People liked mutual help and learned a shortcut. They lacked documentation and wanted more testing time. Documenting the shortcut lets the next group try it independently.

Ask someone outside the original group to use the documented shortcut.

Mary Gorman and Ellen Gottesdiener, The 4L’s: A Retrospective Technique, EBG Consulting (2010).
