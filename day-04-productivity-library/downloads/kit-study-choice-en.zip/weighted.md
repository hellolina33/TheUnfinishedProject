# Decision Matrix

Compares options against criteria you weight yourself, so the trade-offs are written down, not felt.

1. List the criteria that matter: cost, time, fit, and so on.
2. Give each criterion a weight from 1 to 5.
3. Score each option from 1 to 5 per criterion, multiply by the weight, and add up the totals.

Three vendors vary in cost, timing and maintenance. The team wants weights agreed before seeing the totals.

Option C scores 0.40 × 4 + 0.35 × 3 + 0.25 × 5 = 3.90. A and B each score 3.70. A small lead makes the timing weight worth testing.

Change the timing weight and check whether vendor C remains first.

Pugh matrix, Stuart Pugh (engineering design, 1980s to 1990s). Weighted scoring is its common generalisation.
