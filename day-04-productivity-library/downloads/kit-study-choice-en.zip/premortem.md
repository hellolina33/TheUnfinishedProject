# Pre-Mortem

Asks the team to assume failure in advance, which brings out risks people would hesitate to raise.

1. Imagine it is a year from now and the decision failed.
2. Write three reasons it failed.
3. For each reason, decide one action that lowers the risk.

A release has a fixed launch date, but nobody has booked testing or confirmed approval availability.

Assume the launch slipped. Late testing and unclear approval explain plausible paths to failure. Book testing Tuesday and have someone confirm the approver is available.

Confirm the Tuesday test slot and the person who will sign off before the launch date.

Gary Klein, Harvard Business Review (2007).
