# Eat the Frog

Starts the day with the task you would most like to put off, while your attention is still fresh.

1. Each evening, choose the task you are most likely to avoid tomorrow.
2. Do it first thing, before email.
3. Then work through the rest of the list.

A report is due tomorrow. The introduction has slipped twice while the author answers easy emails.

The introduction has stalled the whole report. Forty minutes is enough to write a first version a colleague can read. Email can move to the next block.

Open the draft at 9 am and finish an introduction a colleague could review at 9:40.

Brian Tracy, Eat That Frog! (2001). The phrase is also attributed to Mark Twain; that attribution is not verified.
