# Implementation Intentions

Turn an intention into an if–then response triggered by a specific situation.

1. Identify the situation where you usually get stuck.
2. Write an if–then action that is under your control.
3. Use the cue and improve the plan if needed.

An urgent message often triggers a rushed yes. The team wants a short check before accepting new work.

The urgent request is the cue. A two-question impact check happens before replying. Test the sequence on the next five requests.

Count how often the impact check happens on the next five urgent requests.

Peter Gollwitzer, implementation-intention research (1990s).
