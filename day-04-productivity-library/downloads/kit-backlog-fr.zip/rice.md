# Score RICE

Classe les options à partir de leur portée, de leur impact, de la confiance et de l’effort.

1. Fixe une période et estime la portée
2. Multiplie portée, impact et confiance
3. Divise par l’effort puis vérifie les hypothèses

Une équipe ne peut livrer qu’une fonction ce trimestre. Elle estime la portée sur le même trimestre et l’effort en personnes-mois.

La fonction A obtient 400 × 2 × 0,8 ÷ 4 = 160. La fonction B obtient 800 × 1 × 0,5 ÷ 5 = 80. A touche moins de personnes, mais son impact estimé par personne et le niveau de confiance la placent devant.

Vérifie les hypothèses de portée et de confiance avant d’engager l’option à 160 points.

Sean McBride, blog d’Intercom (article daté de 2018).
