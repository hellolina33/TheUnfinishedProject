# Pré-mortem

Imagine que le projet a échoué pour faire émerger les causes à prévenir.

1. Décris un échec plausible
2. Liste les causes
3. Prépare une mesure pour la plus probable

Une mise en ligne a une date fixe, mais personne n’a réservé de test ni confirmé la disponibilité des valideurs.

Imagine que la mise en ligne a glissé. Des tests tardifs et une validation floue expliquent deux scénarios plausibles. Réserve mardi et fais confirmer la disponibilité du valideur.

Confirme le créneau de test mardi et la personne qui validera avant le lancement.

Gary Klein, Harvard Business Review (2007).
