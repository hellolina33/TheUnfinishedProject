# Blocs de temps

Réserve des plages à des activités précises dans l’agenda.

1. Liste tes activités
2. Réserve des plages et des marges
3. Ajuste selon le temps réellement utilisé

Une personne a raté deux séances de rédaction parce que les appels et les factures ont occupé la matinée.

Réserve 9 h à la rédaction. Donne aux factures et aux appels fournisseurs leurs propres créneaux pour qu’ils ne grignotent pas cette plage.

Vérifie si le créneau de 9 h est utilisé trois jours de suite.

Origine diffuse. Cal Newport décrit la pratique dans Deep Work (2016).
