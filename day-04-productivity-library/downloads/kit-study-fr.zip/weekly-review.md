# Revue hebdomadaire

Réconcilie notes, agenda et engagements avant de planifier la semaine suivante.

1. Traite les entrées
2. Revois les échéances et les projets
3. Bloque du temps pour les priorités

Six notes et deux dossiers restent ouverts vendredi, et un rendez-vous important attend une confirmation.

Traite les six notes, confirme le rendez-vous et programme les deux relances. Réserve ensuite mardi au travail restant le plus important.

Commence lundi sans note inexpliquée et avec un créneau protégé pour la prochaine priorité.

David Allen, Getting Things Done (2001).
