# Principe de Pareto

Repère les causes qui contribuent le plus au problème mesuré.

1. Compte les incidents sur une période
2. Classe les causes par fréquence
3. Traite la première puis mesure de nouveau

Une équipe de livraison recense 100 incidents en avril. Elle dispose d’une semaine pour agir et classe chaque incident par cause principale.

Les retours tardifs expliquent 52 incidents sur 100. Avec les validations lentes, le cumul atteint 77. Pour franchir 80 %, il faudrait inclure une troisième cause. L’équipe n’a qu’une semaine : elle teste d’abord une mesure sur la cause principale.

Teste un délai de retour de 24 h sur un projet. Compare le nombre d’incidents liés aux retours tardifs pour 100 livraisons sur une période comparable.

Vilfredo Pareto, travaux sur la répartition des revenus (1896). Joseph Juran a popularisé la règle des 80/20 au milieu du XXe siècle.
