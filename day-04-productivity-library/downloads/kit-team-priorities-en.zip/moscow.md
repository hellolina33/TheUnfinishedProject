# MoSCoW

Settles scope fast by sorting each item into one of four buckets, and says out loud what will not be done.

1. List every item the goal needs.
2. Label each one: Must (the goal fails without it), Should, Could, or Won’t this round.
3. If the Musts alone take more time than you have, split the goal into two.

A product team can ship a basic login this sprint. Extra sign-in options compete for the same engineering time.

Without sign-in the release cannot serve its purpose. Password reset matters but can follow if support has a workable fallback. A dark theme and social sign-in can wait.

Ask whether the product can be used without each proposed feature. Record the agreed release boundary.

Dai Clegg, for the DSDM agile method (1994).
