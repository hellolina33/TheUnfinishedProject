# Timeboxing

Fixes the time you spend on something, not the result. When the box ends, you stop and decide.

1. Decide how long the task gets before you start.
2. Set a timer. Work until it rings.
3. Then choose one: finish, extend once with a stated reason, or stop and log what is left.

A one-hour deadline leaves only enough time for an outline, a review and a usable handoff.

Spend 30 minutes drafting, 15 reviewing and 15 sending. At minute 30, switch to review if the essential points exist. Record any detail to revisit separately.

At minute 30, stop drafting and verify that the essential points are present.

James Martin, Rapid Application Development (1991). Used in the DSDM method.
