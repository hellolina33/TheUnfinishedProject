# Shutdown Ritual

End each workday with a consistent review and a clear transition out of work.

1. Capture unfinished work and stray thoughts.
2. Identify tomorrow's first priority.
3. Close work apps and use a consistent sign-off cue.

A supplier quote and two emails stay on someone’s mind after the laptop closes.

The quote follow-up becomes a dated task and the 9 am call is tomorrow’s first action. The laptop can close once open commitments have somewhere to go.

Start at 9 am with the planned call and check whether any open commitment lacked a next action.

Cal Newport, Deep Work (2016).
