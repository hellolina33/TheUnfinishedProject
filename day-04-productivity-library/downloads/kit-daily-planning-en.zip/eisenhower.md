# Eisenhower Matrix

Sorts a messy list into four actions, so the urgent does not crowd out the important.

1. List every task on the table. Keep it to about fifteen items.
2. Ask two questions of each: is it important? is it urgent?
3. Put each task in one box. Do the top right now, schedule the top left, drop the bottom left.
4. Delegate the bottom right, or send a one-line reply that hands it back.

A small shop has a checkout outage, a budget deadline and a backlog of reporting tasks.

Checkout blocks current sales, so it goes first. Thursday’s budget work still needs a protected slot. The duplicate report can be removed without losing information.

Check that checkout works and that the budget slot is still booked on Thursday.

Quote attributed to Dwight D. Eisenhower (1954 speech). Popularised by Stephen Covey, The 7 Habits of Highly Effective People (1989).
