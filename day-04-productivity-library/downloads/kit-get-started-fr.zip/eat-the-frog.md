# Commencer par le plus difficile

Réserve ton premier créneau à la tâche que tu repousses.

1. Choisis une tâche importante que tu évites
2. Définis un premier résultat visible
3. Travaille dessus avant d’ouvrir ta messagerie

Un rapport est attendu demain. Son introduction a déjà été repoussée deux fois au profit de courriels faciles à traiter.

L’introduction bloque tout le rapport. Quarante minutes suffisent pour écrire une première version lisible par un collègue. Les courriels passent au créneau suivant.

Ouvre le brouillon à 9 h et termine une introduction qu’un collègue pourra relire à 9 h 40.

Brian Tracy, Eat That Frog! (2001). L’attribution de la formule à Mark Twain reste incertaine.
