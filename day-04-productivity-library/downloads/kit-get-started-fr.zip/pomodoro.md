# Technique Pomodoro

Alterne des périodes de travail ciblé et de vraies pauses.

1. Choisis une tâche
2. Travaille 25 minutes puis fais une pause de 5 minutes
3. Prends une pause plus longue après quatre blocs

Un auteur a deux heures pour rédiger et passe aux messages chaque fois que le paragraphe suivant se complique.

Fais le plan au premier bloc, puis rédige une partie à chaque bloc suivant. Une pause courte les sépare. La pause longue vient après le quatrième.

Compte les parties rédigées après quatre blocs et note les interruptions.

Francesco Cirillo, fin des années 1980.
