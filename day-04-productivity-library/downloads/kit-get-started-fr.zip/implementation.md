# Plans « si… alors… »

Associe un déclencheur concret à une action définie à l’avance.

1. Choisis un signal observable
2. Écris une réponse faisable
3. Teste puis change le signal si nécessaire

Un message urgent déclenche souvent un oui précipité. L’équipe veut faire un contrôle rapide avant d’accepter un travail.

La demande urgente sert de signal. Un contrôle d’impact en deux questions précède la réponse. Teste cette séquence sur les cinq prochaines demandes.

Compte les contrôles d’impact sur les cinq prochaines demandes urgentes.

Peter Gollwitzer, travaux sur les intentions de mise en œuvre (années 1990).
