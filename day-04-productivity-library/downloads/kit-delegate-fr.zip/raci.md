# Matrice des responsabilités RACI

Précise qui exécute, qui valide, qui conseille et qui reçoit l’information.

1. Liste les livrables
2. Attribue les rôles par livrable
3. Vérifie qu’une personne tranche pour chaque ligne

Un contrat reste sans signature parce que plusieurs collègues pensent que quelqu’un d’autre le valide.

Léa rédige le contrat et Sam le valide. Noor et Lina ont d’autres rôles. Les nommer évite que chacun attende la signature d’un autre.

Vérifie que chaque livrable a un valideur et que le contrat arrive chez Sam.

Matrice de répartition des responsabilités utilisée en gestion de projet. Auteur unique non établi.
