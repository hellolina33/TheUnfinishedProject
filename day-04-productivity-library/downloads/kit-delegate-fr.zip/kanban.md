# Kanban d’équipe

Observe la circulation du travail et les étapes où les demandes s’accumulent.

1. Cartographie le flux
2. Fixe une limite par étape
3. Observe les cartes qui stagnent

Les demandes de remboursement s’accumulent à la validation financière. En accepter davantage ne fait pas avancer la file.

Les remboursements en attente de validation sont plus anciens que les nouvelles demandes. Aide à dégager cette file avant d’augmenter les entrées.

Compare l’ancienneté des remboursements en attente avant et après le renfort à la validation.

David J. Anderson, Kanban (2010). Racines dans le système de production Toyota.
