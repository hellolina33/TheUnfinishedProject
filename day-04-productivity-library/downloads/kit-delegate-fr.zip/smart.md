# Objectifs SMART

Transforme une intention en résultat observable assorti d’une échéance.

1. Nomme le résultat
2. Choisis un indicateur et une cible réaliste
3. Fixe une date de vérification

Les réponses du support prennent en moyenne 48 h. Le responsable dispose de deux permanences pour tester un délai plus court.

L’équipe part de 48 h et vise 24 h au 30 juin. Les deux permanences sont le moyen à tester. La cible porte toujours sur le délai de réponse.

Mesure le même délai de réponse le 30 juin et compare-le à la cible de 24 h.

George T. Doran, article sur les objectifs SMART (1981).
