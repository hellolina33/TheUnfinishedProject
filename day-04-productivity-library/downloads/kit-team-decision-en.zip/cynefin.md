# Cynefin Framework

Match your response to the type of situation instead of applying one decision process everywhere.

1. Describe the situation without deciding too quickly.
2. Ask whether cause and effect are obvious, analyzable, emergent or unstable.
3. Choose best practice, expert analysis, safe-to-fail probes or immediate stabilization accordingly.

A service desk handles a documented reset, a puzzling outage, a new service and an active incident.

A documented reset follows the procedure. An unusual outage needs expertise. A new service needs a small probe. A live incident needs containment before analysis.

Check that each issue receives a response appropriate to its uncertainty.

Dave Snowden; Snowden and Boone, 'A Leader's Framework for Decision Making', HBR (2007).
