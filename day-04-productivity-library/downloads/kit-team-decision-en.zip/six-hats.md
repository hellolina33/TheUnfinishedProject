# Six Thinking Hats

Gives a group one way of thinking at a time, so critics and optimists stop talking over each other.

1. Write the decision on a page.
2. Spend five minutes on each hat: facts, feelings, risks, benefits, ideas, process.
3. Decide after the blue hat, not before.

A team is debating a new supplier workflow. Facts, workload fears and pilot ideas are mixed together.

Twelve requests are a fact. Concern about workload is a reaction. Supplier delay is a risk. A limited pilot is an idea that can be tested against those inputs.

Write a pilot decision with one risk to monitor and one benefit to measure.

Edward de Bono, Six Thinking Hats (1985).
