# SMART Goals

Turn vague ambitions into specific, measurable and time-bounded commitments.

1. Write the goal in one sentence.
2. Add a measure and a realistic target.
3. Set a date and explain why the goal matters.

Support replies currently take 48 hours on average. The lead has two coverage shifts to test a shorter target.

The team starts at 48 hours and aims for 24 by 30 June. Two coverage shifts are the mechanism to test. The target stays about response time.

Measure the same response-time indicator on 30 June and compare it to the 24-hour target.

George T. Doran, 'There's a S.M.A.R.T. Way to Write Management's Goals and Objectives' (1981).
