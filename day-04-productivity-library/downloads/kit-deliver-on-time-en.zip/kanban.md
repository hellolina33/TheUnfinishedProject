# Kanban Board

Shows all work as cards in columns. A limit on Doing stops you starting ten things at once.

1. Draw three columns: To do, Doing, Done.
2. Write each task on a card in To do.
3. Move one card to Doing. Keep Doing to two cards at most.

Refund requests build up at finance approval. Taking more requests does not move the queue.

Refunds waiting at finance approval are older than new requests. Help finance clear the approval queue before increasing intake.

Review the age of pending refunds before and after helping finance clear the queue.

David J. Anderson, Kanban (2010). Roots in the Toyota Production System (Taiichi Ohno).
