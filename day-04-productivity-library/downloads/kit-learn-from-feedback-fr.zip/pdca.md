# Cycle PDCA

Teste une amélioration, mesure son effet, puis décide de l’adopter ou de l’ajuster.

1. Fixe une mesure avant le test
2. Essaie à petite échelle
3. Compare puis décide de la suite

Une équipe support veut réduire un délai médian de 48 h avec une petite modification du traitement des demandes.

La médiane initiale était de 48 h. Le pilote sur dix demandes donne 29 h. Répète avec un groupe comparable avant de considérer l’amélioration comme durable.

Répète le pilote sur un groupe comparable et compare les médianes avant de généraliser.

Cycle de Shewhart popularisé par W. Edwards Deming.
