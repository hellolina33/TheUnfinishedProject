# Les cinq pourquoi

Remonte des symptômes aux causes vérifiables en posant plusieurs fois la question « pourquoi ? ».

1. Décris un incident observable
2. Cherche une cause puis vérifie-la
3. Continue jusqu’à une cause sur laquelle agir

Trois livraisons ont pris du retard après l’arrivée de demandes de validation incomplètes.

La livraison a tardé parce que la validation a commencé tard. Un champ obligatoire manquait. Compare les anciens formulaires aux demandes complètes avant d’attribuer la correction.

Vérifie l’absence du champ dans les anciennes demandes. Teste le formulaire corrigé sur les cinq prochaines livraisons.

Pratique du système de production Toyota associée à Sakichi Toyoda.
