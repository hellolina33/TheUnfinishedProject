# Revue après action

Compare ce qui était prévu et ce qui s’est produit pour ajuster la prochaine exécution.

1. Retrouve l’objectif initial
2. Décris le résultat observé
3. Explique l’écart puis choisis une suite

Une livraison prévue à midi arrive à 14 h. L’équipe doit comprendre l’écart avant de reprendre le même plan.

L’équipe visait midi et a livré à 14 h. Les données sont arrivées tard. Les demander la veille donne une correction à tester au prochain essai.

Demande les données la veille et relève l’heure réelle de la prochaine livraison.

Armée américaine, revue après action formalisée dans les années 1970.
