# Deep Work

Protects long stretches for work that needs full concentration, and moves shallow tasks elsewhere.

1. Choose one block of 60 to 90 minutes a day for your hardest work.
2. Turn off notifications and close unrelated tabs.
3. Before you stop, write the next step on paper. It makes restarting faster.

An analyst needs to validate a model and interpret its results before replying to routine requests.

Use the first block for a reproducible model test and the second to write the interpretation. Routine requests wait until the focused output exists.

Check whether both focus blocks produced a reproducible test and a written interpretation.

Cal Newport, Deep Work (2016).
