# Méthode MoSCoW

Fixe le périmètre en séparant les exigences indispensables des options.

1. Liste les exigences
2. Teste ce qui rendrait la livraison inutilisable
3. Reporte les options au-delà de la capacité

Une équipe produit peut livrer une connexion de base ce cycle. Les options de connexion supplémentaires mobilisent le même temps de développement.

Sans connexion, cette version ne remplit pas son objectif. La réinitialisation compte, mais peut suivre si le support a une solution temporaire. Le thème sombre et la connexion sociale peuvent attendre.

Demande si le produit reste utilisable sans chaque fonction. Consigne le périmètre convenu.

Dai Clegg, méthode agile DSDM (1994).
