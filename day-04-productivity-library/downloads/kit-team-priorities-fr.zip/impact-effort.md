# Matrice impact–effort

Compare la valeur attendue et le travail nécessaire avant de choisir.

1. Définis une mesure d’impact
2. Estime l’effort sur la même échelle
3. Choisis un gain rapide et examine les grands projets

Une boutique peut faire une petite correction cette semaine. Un lien cassé bloque certains acheteurs et la refonte du paiement prendrait plusieurs semaines.

Le lien cassé se répare vite et bloque le paiement. La refonte peut aider davantage d’acheteurs, mais l’équipe doit estimer le travail et vérifier l’intérêt avant de la planifier.

Vérifie que le lien fonctionne et mesure combien d’acheteurs abandonnent encore à cette étape.

Matrice courante en gestion de produit et en conseil. Auteur unique non établi.
