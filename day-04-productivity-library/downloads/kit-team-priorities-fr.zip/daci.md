# Cadre de décision DACI

Clarifie qui pilote la décision, qui tranche, qui contribue et qui doit être informé.

1. Définis la question et l’échéance
2. Nomme le pilote et le décideur
3. Consulte les contributeurs et diffuse la décision

Plusieurs personnes contribuent au choix d’un fournisseur sans que personne ne sache qui tranche.

Sam rassemble les contributions de Noor et prépare les options. Léa tranche à l’échéance, puis l’équipe reçoit la décision et sa justification.

Confirme que Léa tranche à l’échéance et que l’équipe reçoit la justification.

Cadre DACI associé à Intuit.
