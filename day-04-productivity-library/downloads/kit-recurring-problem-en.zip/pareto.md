# Pareto 80/20

Shows which few causes produce most of the problem, so the effort goes where it counts.

1. For two weeks, log the cause of each delay, error or complaint.
2. Count each cause and sort from largest to smallest.
3. Work on the top one or two causes. Count again after a month.

A delivery team logs 100 incidents in April. It has one week to address recurring delays and classifies each incident by its primary cause.

Late feedback accounts for 52 of 100 incidents. Adding slow approvals brings the cumulative total to 77. If the team used 80% as a cutoff, it would need a third cause. With one week available, it chooses to test the largest cause first.

Test a 24-hour feedback deadline on one project. Compare the number of late-feedback incidents per 100 deliveries in the next comparable period.

Vilfredo Pareto (1896, income distribution). The 80/20 name was given by Joseph Juran (1940s to 1950s).
