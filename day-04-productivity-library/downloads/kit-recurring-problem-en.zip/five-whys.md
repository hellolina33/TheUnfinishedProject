# Five Whys

Trace a problem past its first explanation by asking 'why?' repeatedly, without assuming five is magic.

1. State the problem factually.
2. Ask why, recording evidence rather than blame.
3. Stop at a cause you can investigate or change.

Three deliveries were late after approval requests arrived incomplete.

Delivery was late because approval started late. The requests lacked a required field. Compare old forms with completed requests before assigning someone to update the form.

Check past requests for the missing field. Test the revised form on the next five deliveries.

Toyota production-system practice associated with Sakichi Toyoda.
