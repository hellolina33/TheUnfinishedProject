# PDCA

Improve a process through short cycles of planning, testing, learning and adjustment.

1. Plan one small process change.
2. Try it with a measurable result.
3. Check the outcome and adopt or adjust the process.

A support team wants to reduce a 48-hour median delay with a small change to request handling.

The baseline median was 48 hours. The ten-request pilot recorded 29 hours. Repeat with a comparable group before treating the apparent improvement as durable.

Repeat the pilot on a comparable group and compare medians before standardising.

Shewhart cycle, popularized by W. Edwards Deming; often called PDCA.
