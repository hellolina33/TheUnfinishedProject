# RICE Scoring

Adds reach and effort to ICE, so a popular but expensive feature does not win by default.

1. Estimate Reach: how many people it touches in a set period.
2. Score Impact, Confidence (as a percentage) and Effort in person-weeks.
3. Calculate Reach × Impact × Confidence ÷ Effort. Sort the list by the result.

A team has room for one feature this quarter. It estimates reach over the same quarter and effort in person-months.

Feature A scores 400 × 2 × 0.8 ÷ 4 = 160. Feature B scores 800 × 1 × 0.5 ÷ 5 = 80. A reaches fewer people, but the estimated impact per person and confidence make it rank higher.

Recheck the reach and confidence assumptions before committing to the 160-point option.

Sean McBride, Intercom blog (article dated 2018).
