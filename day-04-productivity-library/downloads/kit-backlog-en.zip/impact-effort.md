# Impact–Effort Matrix

Puts ideas on two axes, so quick wins are visible at a glance and heavy work is weighed against its payoff.

1. Write each task on its own card.
2. Place each card by Impact (up is high) and Effort (right is high).
3. Do the quick wins now. Schedule the major projects. Drop the thankless tasks.

A shop can do one small fix this week. A broken link blocks some buyers and a checkout redesign needs several weeks.

The broken link is quick to repair and blocks checkout. The larger redesign may help more buyers, but the team needs an effort estimate and evidence before scheduling it.

Confirm the repaired link works and measure how often buyers still abandon that step.

No verified single author. A common two-by-two in product and consulting work.
