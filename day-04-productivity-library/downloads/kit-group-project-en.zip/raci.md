# RACI Matrix

Makes explicit who does the work, who signs it off, who is asked, and who is kept informed.

1. List the deliverables and the people involved, including you.
2. For each deliverable, mark one R (does the work) and one A (signs it off).
3. Mark C (asked) and I (informed) where needed. Check that every row has exactly one A.

A contract sits unsigned because several colleagues think someone else owns the approval.

Lea drafts the contract and Sam approves it. Noor and Lina have other roles. Naming those roles stops everyone from waiting for someone else to sign.

Confirm that each deliverable has one named approver and that the contract reaches Sam.

No verified single author. A responsibility assignment matrix used in project management for decades.
